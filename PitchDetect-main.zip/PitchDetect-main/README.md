# Pitch Detection

Start and Stop,

Possibility to add graph from a define range value.